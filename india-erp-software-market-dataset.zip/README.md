# India ERP Software Market — Structured Dataset

This repository contains a structured dataset for the **India ERP Software Market**, created based on publicly available information.  
It follows the formatting style of the Immunoglobulin Market Dataset repository.

## 📁 Files Included
- `market_overview.csv` — Year-wise market size and growth rate  
- `segmentation.csv` — Component, deployment, enterprise size, and industry segmentation  
- `metadata.json` — Dataset metadata and source reference  
- `README.md` — Documentation for GitHub

## 📊 Overview
This dataset is intended for analysis, visualization, machine learning experiments, and academic or market research purposes.

## 🔗 Source
Dataset constructed using openly available summaries from NextMSC:  
India ERP Software Market — Report IC3611
